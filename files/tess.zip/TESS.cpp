/*************************************************************************
 **                                                                     **
 **						TURKEY ELECTRICITY SYSTEM SIMULATION            **
 **                        (c) Serdal Bahce                             **
 **                     SERDAL BAHCE AND EROL TAYMAZ                    **
 **                  MIDDLE EAST TECHNICAL UNIVERSITY 2003              **
*************************************************************************/

#include <iostream.h>
#include <math.h>
#include <time.h>
#include <fstream.h>
#include <conio.h>
#include <stdlib.h>

#define MAX 130


/* INITIAL GLOBAL DEFINITIONS */

double r[MAX][MAX], nv[MAX][MAX],z[MAX];
double l[MAX][MAX], u[MAX][MAX];
double m1[MAX][MAX],m2[MAX][MAX],m3[MAX][MAX],m4[MAX][MAX],m5[MAX][MAX];
double gen[30],flw[75],blambda[45],flambda[75],glambda[30],dlambda[45];
double dem[45];
double bangle[45];
double price[MAX], profit[MAX],csurplus[MAX],dprofit[MAX],priced[MAX],dbprice[MAX];
double loss[75];
double demt[3][24];
double lost[3][24];
int buscount,gencount,mgencount,demcount;
int linecount,linecount1,cdemcount,kflw[75];
double proftot[3][24],dproftot[24];
double csurplustot[3][24],csurplustot1[3][24],csurplustot2[3][24];
double socwelfare[3][24];
double gentot[3][24];
double reginc[24],admprice;
double avgsprice[3][24],avgbprice[3][24], avgbprice1[2][24],avgdbprice[24];
double dgproftot[3],dcsurplustot[3],dcsurplustot1[3], dcsurplustot2[3],ddproftot, dgentot[3],ddemt[3],dlost[3];
double dsocwelfare[3];
int flag;
int choice;

/*GLOBAL OBJECT DEFINITIONS*/
/* DEMAND OBJECT*/
class Demand{
   public:
   	double A;
      double B[24],C[24];
      int cstatus;
      double dcontract;
      double dcprice;
      int dcbno;
      int dmstatus;
      double bdem[24];
      double kdem[24];
      double min1;
      double max1;
      void get_cstatus (int r);
      void get_dcontract(double r);
      void getdempar(ifstream& inp);
      void get_cbno(int r);
      void get_dmin(double r);
      void get_dmax(double r);
      void get_bdem(ifstream& inp);
      };


void Demand::getdempar(ifstream& inp)

 	{
     int x;
     inp>>A;
     for(x=0; x<24; x++) inp>>B[x];
     for(x=0; x<24; x++) inp>>C[x];

   }

 void Demand::get_cstatus (int r)
	{
   	cstatus=r;
   }
void Demand::get_dcontract(double r)
	{
     dcontract=r;
   }
void Demand::get_cbno(int r)
	{
   	dcbno=r;
   }
void Demand::get_dmin(double r)
	{
     min1=r;
   }
void Demand::get_dmax(double r)
	{
    max1=r;
    }

void Demand::get_bdem(ifstream& inp)
{
   int x;
   for (x=0; x<24; x++)
   {
	inp>>bdem[x];
   kdem[x]=bdem[x];
   bdem[x]=0.5*bdem[x];
   }
   }


/*GENERATOR OBJECT*/

class Gen{
   public:
   	double A,B,C;
      int cstatus;
      double contract;
      double cprice;
      int cbno;

      void get_contract(double r);
      void getgenpar(double n1, double n2,double n3);
      void get_cstatus (int r);
      void get_cbno(int r);


       };

 void Gen::getgenpar(double n1, double n2,double n3)

 	{

     A=n1;
     B=n2;
     C=n3;
   }

 void Gen::get_cstatus (int r)
	{
   	cstatus=r;
   }
void Gen::get_contract(double r)
	{
     contract=r;
   }
void Gen::get_cbno(int r)
	{
   	cbno=r;
   }


class Connection{
  	public:
   	int bus_no;
      int line_no;
      void get_conbusno(int r);
      void getlineno(int r);
   };

  void Connection::get_conbusno(int r) {

         bus_no=r;
         }

  void Connection::getlineno(int r) {

         line_no=r;
         }

/*BUS OBJECT*/

class Bus{
    public:
  		int bus_no;
      int bus_type;
      int genno;
      int rdum;
      Gen genb[5];
      int mgenstatus[5];
      double Load[24];
      double Load1[2];
      double Genmax[5];
      int con_no;
      Demand dem;
      Connection Con[MAX];
  	   Bus();
      void get_condata(ifstream& input1);
      void get_bus_type(int i);
      void get_load();
      void get_genpar(double n1,double n2, double n3, Gen genc[5], int r);
      void get_conno(int p);
      void get_max(double kt, int r);
      void initL2(int k);
      void get_genno(int i);
      };

  Bus::Bus()
  	{
   	bus_no=0;
   }

  void Bus::get_genno (int i) {

  		genno=i;
      }

  void Bus::get_bus_type(int i) {


         bus_type=i;
          }

  void Bus::get_load() {
         int y;
         for (y=0; y<24; y++)Load[y]=dem.kdem[y];


         }


 void Bus::get_genpar(double n1, double n2, double n3,Gen genc[5], int r ){
         genc[r].getgenpar(n1,n2,n3);
         genb[r]=genc[r];
 		}

 void Bus::get_conno(int p){


        con_no=p;
         }


 void Bus::get_condata(ifstream& input1) {
      int k,l;

      for (k=0; k<con_no; k++)
      	{
           input1>>l;
           Con[k].get_conbusno(l);
           input1>>l;
           Con[k].getlineno(l);
         }

      }

 void Bus::get_max(double kt, int r){

      Genmax[r]=kt;
      }

  void Bus::initL2(int k)
	{
      for (k=0; k<con_no; k++)
   	Load1[k]=0;
   }


Bus sBus[45];

/*LINE OBJECT*/

class Line {
  	 public:
        Line();
        int line_no;
        int status;
        double suspect;
        double LineMax;
        double resist;
        double lc;
        int linestatus;
    	  int Busno1,Busno2;
        void getlinemax(double k);
        void get_statusf();
        void get_statust(int t);
        void get_suspectance(double t, double r);
        void initialstatus();

     };


 Line::Line() {

         line_no=0;
         }

 void Line::initialstatus()
 	{
     linestatus=1;
   }

void Line::getlinemax(double k) {


      LineMax=k;
      }
void Line::get_statusf()
	{
      status=0;
   }

void Line::get_suspectance(double t, double r)

	{

      suspect=t;
      resist=r;
      lc=(2*resist)/((resist*resist)+(suspect*suspect));
      suspect=1/suspect;
   }


Line sLine[75];

 void getbusno(int n) {

        int k,l;

        for (k=0; k<n; k++)
         for (l=0; l<sBus[k].con_no; l++)
           if (sLine[sBus[k].Con[l].line_no].linestatus==1)
             {
             	sLine[sBus[k].Con[l].line_no].Busno1=sBus[k].bus_no;
               sLine[sBus[k].Con[l].line_no].Busno2=sBus[k].Con[l].bus_no;
              	sLine[sBus[k].Con[l].line_no].linestatus=2;
          		}

 	}

 /*  INITIALIZATION OF VARIABLES     */

 void initialguess(int c0, int c1, int c2)
       {
        int x;
        for (x=0; x<c2-1; x++) bangle[x]=10;
        for(x=0; x<c0; x++) gen[x]=400;

        for (x=0; x<c2; x++) blambda[x]=5;
        for (x=0; x<c1; x++) flambda[x]=3;
        for (x=0; x<c2; x++) glambda[x]=3;
        }

void initialguess12(int c0, int c1, int c2, int c3)
       {
        int x;
        for (x=0; x<c2-1; x++) bangle[x]=10;
        for(x=0; x<c0; x++) gen[x]=400;

        for (x=0; x<c2; x++) blambda[x]=5;
        for (x=0; x<c1; x++) flambda[x]=3;
        for (x=0; x<c2; x++) glambda[x]=3;
         for(x=0; x<c3; x++) dem[x]=200;

        }
void matrixmullow (int dim)
	{
   	int x,y,z;
      double sum;
      double n[MAX][MAX];
       for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
   	{
        sum=0;
        for (z=0; z<dim; z++)
        	sum=sum+l[y][z]*r[z][x];
        n[y][x]=sum;
       }

      for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++) r[y][x]=n[y][x];
   }

/*    MATRIX OPEARTIONS           */

 void matrixmulup (int dim)
	{
   	int x,y,z;
      double sum;
      double n[MAX][MAX];
       for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
   	{
        sum=0;
        for (z=0; z<dim; z++)
        	sum=sum+u[y][z]*r[z][x];
        n[y][x]=sum;
       }

      for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++) r[y][x]=n[y][x];
  }

 void matrixmul1low (int dim)
	{
   	int x,y,z;
      double sum;
      double n[MAX][MAX];
       for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
   	{
        sum=0;
        for (z=0; z<dim; z++)
        	sum=sum+l[y][z]*nv[z][x];
        n[y][x]=sum;
       }

      for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++) nv[y][x]=n[y][x];

   }

void matrixmul1up (int dim)
	{
   	int x,y,z;
      double sum;
      double n[MAX][MAX];
       for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
   	{
        sum=0;
        for (z=0; z<dim; z++)
        	sum=sum+u[y][z]*nv[z][x];
        n[y][x]=sum;
       }

      for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++) nv[y][x]=n[y][x];
}


void initl (int dim)
	{
   	int y,x;
       	for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
         	{
            	if(x==y)l[y][x]=1;
               	else l[y][x]=0;
            }
   }

void initu (int dim)
	{
   	int y,x;
       	for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
         	{
            	if(x==y)u[y][x]=1;
               	else u[y][x]=0;
            }
   }

  void obtainl (int dim, int g)
 	{
    int x;


    for (x=0; x<dim; x++)
    	{
      	if (x<g) l[x][g]=0;
          else if(x==g) l[x][g]=1/r[g][g];
               else l[x][g]=-r[x][g]/r[g][g];
    	}
    }

void obtainu(int dim, int k)
   {
    int x;
       for (x=0; x<dim; x++)
       	{
         	if (x<k) u[x][k]=-r[x][k];
         }
   }






void reorder(int dim, int gencount, int buscount)
	{
   	int y, x;

      for(y=0; y<buscount-1; y++)
      	{
            for (x=0; x<dim; x++)
         	r[gencount+y][x]=r[gencount+y][x]+r[gencount+buscount+y-1][x];
         }
   }

void reorder12(int dim, int gencount, int buscount, int demcount)
	{
   	int y, x;

      for(y=0; y<buscount-1; y++)
      	{
            for (x=0; x<dim; x++)
         	r[gencount+y+demcount][x]=r[gencount+y+demcount][x]+r[gencount+buscount+y-1+demcount][x];
         }
   }
void arrinverse(int dim,int gencount, int buscount)
 	{
   	int x,y;
       for(y=0; y<buscount-1; y++)
      	{
            for (x=0; x<dim; x++)
         	nv[x][gencount+buscount-1+y]=nv[x][gencount+buscount-1+y]+nv[x][y+gencount];
         }

    }

void arrinverse12(int dim,int gencount, int buscount, int demcount)
 	{
   	int x,y;
       for(y=0; y<buscount-1; y++)
      	{
            for (x=0; x<dim; x++)
         	nv[x][gencount+buscount-1+y+demcount]=nv[x][gencount+buscount-1+y+demcount]+nv[x][y+gencount+demcount];
         }

    }
void reorder1(int dim, int k)
 	{
   	int x,y;
      double tem;
      x=k+1;
      y=0;
      do
      {
      	if (!(r[x][k]==0)) y=1;
         x=x+1;
      }
      while ((y==0)&&(x<dim));
      x=x-1;

      for (y=0; y<dim; y++)
           {
            tem=r[k][y];
           	r[k][y]=r[x][y];
            r[x][y]=tem;
            }
       for (y=0; y<dim; y++)
           {
            tem=nv[k][y];
           	nv[k][y]=nv[x][y];
            nv[x][y]=tem;
            }
    }


void ident(int dim, double t[MAX][MAX])
{
	int y,x,cn;
   double n[MAX][MAX],sum;
   for (y=0; y<dim; y++)
   for (x=0; x<dim; x++)
   	{
        sum=0;
        for (cn=0; cn<dim; cn++)
        	sum=sum+t[y][cn]*nv[cn][x];
        n[y][x]=sum;

        }



}



void matrixoper(int dim, int gencount, int buscount)
 {
   int x,y;
   double t[MAX][MAX];


   for (y=0; y<dim; y++)
   	for (x=0; x<dim; x++) t[y][x]=r[y][x];





   for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
         	{
            	if(x==y)nv[y][x]=1;
               	else nv[y][x]=0;
            }
     reorder(dim, gencount, buscount);
     for (x=0; x<dim; x++)
      	{

            if (r[x][x]==0) reorder1(dim,x);
            initl(dim);
         	obtainl(dim,x);
            matrixmullow(dim);
            matrixmul1low(dim);

         }

         for(x=dim-1; x>0; x--)
      	{

            initu(dim);
         	obtainu(dim,x);
            matrixmulup(dim);
            matrixmul1up(dim);

         }

        arrinverse(dim,gencount,buscount);



       ident(dim,t);
    for (y=0; y<dim; y++)
   	for (x=0; x<dim; x++) r[y][x]=t[y][x];


 }

 void matrixoper12(int dim, int gencount, int buscount, int demcount)
 {
   int x,y;
   double t[MAX][MAX];


   for (y=0; y<dim; y++)
   	for (x=0; x<dim; x++) t[y][x]=r[y][x];





   for (y=0; y<dim; y++)
   		for (x=0; x<dim; x++)
         	{
            	if(x==y)nv[y][x]=1;
               	else nv[y][x]=0;
            }
     reorder12(dim, gencount, buscount, demcount);
     for (x=0; x<dim; x++)
      	{

            if (r[x][x]==0) reorder1(dim,x);
            initl(dim);
         	obtainl(dim,x);
            matrixmullow(dim);
            matrixmul1low(dim);

         }

         for(x=dim-1; x>0; x--)
      	{

            initu(dim);
         	obtainu(dim,x);
            matrixmulup(dim);
            matrixmul1up(dim);

         }

        arrinverse12(dim,gencount,buscount,demcount);
        ident(dim,t);
    for (y=0; y<dim; y++)
   	for (x=0; x<dim; x++) r[y][x]=t[y][x];


 }

/*   JACOBIAN AND HESSIAN MATRICES    */

void jacobian(int c0, int c1, int c2, double temk[MAX],double nv1[MAX][8],  int daycount)
	{
   	int x,y,t,n1;

      t=0;
      double n,n11,nt1;
      for (x=0; x<c0; x++)
          {

           if (nv1[x][6]==0)
           n=nv1[x][1]+2*nv1[x][2]*gen[x];
           if (nv1[x][6]==1)
           n=nv1[x][1]+2*nv1[x][2]*(gen[x]+nv1[x][7]);
           n11=0;

           if (nv1[x][3]==2)
            {
            cout<<"for generator "<<x<<"\n";
           	n11=glambda[x];

            }
           if (nv1[x][3]==3)n11=-glambda[x];
           for (y=0; y<c2; y++)
                    {

                    n11=n11+r[x][c0+c2+y-1]*blambda[y];

                    }


          temk[t]=n+n11;
          t=t+1;
           }

      for (x=0; x<c2-1; x++)
          {
           n=0;
           for (y=0; y<c2; y++)
           n=n+r[x+c0][c0+c2+y-1]*blambda[y];
           for (y=0; y<c1; y++)
           	{
            if (sLine[y].status==1)
            {
            n=n+m5[y][x]*flambda[y];
            }
            if (sLine[y].status==-1)
            {
            n=n-m5[y][x]*flambda[y];
            }
            }
           temk[t]=n;
           t=t+1;
           }

      for (x=0; x<c2; x++)
          {
          	n=sBus[x].Load[daycount];
            if (!(sBus[x].bus_type==1))
            {
            	for(y=0; y<sBus[x].genno; y++)
               	if(!(sBus[x].genb[y].cstatus==0)) n=n-sBus[x].genb[y].contract;
            }
            for (y=0; y<c0; y++)n=n+r[c0+c2+x-1][y]*gen[y];
            for (y=0; y<c2; y++)n=n+r[c0+c2+x-1][c0+y]*bangle[y];
            temk[t]=n;
            t=t+1;
          }

      for(x=0; x<c1; x++)
      	{
         	nt1=0;
         	if (sLine[x].status==1)
            	{

               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1+m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
            if (sLine[x].status==-1)
            	{
               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1-m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
             }


      	n1=0;
      for(x=0; x<c2; x++)
           {
           	  if (!(sBus[x].bus_type==1))
              for(y=0; y<sBus[x].genno; y++)
              {
              if (sBus[x].mgenstatus[y]==2){
                  cout<<"bus no:"<<x<<"  genno:"<<n1<<" max violation"<<"\n";
              		temk[t]=gen[n1]-sBus[x].Genmax[y];
                  if (!(sBus[x].genb[y].cstatus==0)) temk[t]=temk[t]+sBus[x].genb[y].contract;
                  t=t+1;

                  }
              if (sBus[x].mgenstatus[y]==3){
              		 temk[t]=-gen[n1];
                   t=t+1;

                  }
             n1=n1+1;
           }
           }

      }

void jacobian1(int c0, int c1, int c2, double temk[MAX],double nv1[MAX][8], int c3,double dv1[MAX][9], int dv11[MAX], int daycount )
	{
   	int x,y,t,n1;

      t=0;
      double n,n11,nt1;
      for (x=0; x<c0; x++)
          {

           if (nv1[x][6]==0)
           n=nv1[x][1]+2*nv1[x][2]*gen[x];
           if (nv1[x][6]==1)
           n=nv1[x][1]+2*nv1[x][2]*(gen[x]+nv1[x][7]);
           n11=0;

           if (nv1[x][3]==2)
            {

           	n11=glambda[x];


            }
           if (nv1[x][3]==3)n11=-glambda[x];
           for (y=0; y<c2; y++)
                    {

                    n11=n11+r[x][c3+c0+c2+y-1]*blambda[y];

                    }


          temk[t]=n+n11;
          t=t+1;
           }

       for (x=0; x<c3; x++)
          {

           if (dv1[x][6]==0)
           n=-1*(sBus[dv11[x]].dem.B[daycount]+2*sBus[dv11[x]].dem.C[daycount]*(dem[x]+sBus[dv11[x]].dem.bdem[daycount]));
           if (dv1[x][6]==1)
            {
           if (sBus[dv11[x]].dem.dcontract>sBus[dv11[x]].dem.bdem[daycount])
           n=-1*(sBus[dv11[x]].dem.B[daycount]+2*sBus[dv11[x]].dem.C[daycount]*(dem[x]+dv1[x][7]));
           if (sBus[dv11[x]].dem.dcontract<sBus[dv11[x]].dem.bdem[daycount])
           n=-1*(sBus[dv11[x]].dem.B[daycount]+2*sBus[dv11[x]].dem.C[daycount]*(dem[x]+sBus[dv11[x]].dem.bdem[daycount]));
            }
           n11=0;

           if (dv1[x][3]==2)
            {

           	n11=dlambda[x];

            }
           if (dv1[x][3]==3)n11=-dlambda[x];
           for (y=0; y<c2; y++)
                    {

                    n11=n11+r[x+c0][c0+c2+y-1+c3]*blambda[y];

                    }


          temk[t]=n+n11;
          t=t+1;
           }


      for (x=0; x<c2-1; x++)
          {
           n=0;
           for (y=0; y<c2; y++)
           n=n+r[x+c0+c3][c0+c2+y-1+c3]*blambda[y];
           for (y=0; y<c1; y++)
           	{
            if (sLine[y].status==1)
            {
            n=n+m5[y][x]*flambda[y];
            }
            if (sLine[y].status==-1)
            {
            n=n-m5[y][x]*flambda[y];
            }
            }
           temk[t]=n;
           t=t+1;
           }


      for (x=0; x<c2; x++)
          {
            n=0;
            if (!(sBus[x].bus_type==1))
            {
            	for(y=0; y<sBus[x].genno; y++)
               	if(!(sBus[x].genb[y].cstatus==0)) n=n-sBus[x].genb[y].contract;
            }
            if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
            {
               if(!(sBus[x].dem.cstatus==0))
               {
               if (sBus[dv11[x]].dem.dcontract>sBus[x].dem.bdem[daycount])
               n=n+sBus[x].dem.dcontract;
               if (sBus[dv11[x]].dem.dcontract<sBus[x].dem.bdem[daycount])
               n=n+sBus[x].dem.bdem[daycount];
               }
              if((sBus[x].dem.cstatus==0)) n=n+sBus[x].dem.bdem[daycount];

            }
            for (y=0; y<c0; y++)n=n+r[c0+c2+x-1+c3][y]*gen[y];
            for (y=0; y<c3; y++)n=n+r[c0+c2+x-1+c3][y+c0]*dem[y];
            for (y=0; y<c2; y++)n=n+r[c0+c2+x-1+c3][c0+y+c3]*bangle[y];
            temk[t]=n;
            t=t+1;
          }

      for(x=0; x<c1; x++)
      	{
         	nt1=0;
         	if (sLine[x].status==1)
            	{

               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1+m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
            if (sLine[x].status==-1)
            	{
               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1-m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
             }


      	n1=0;
      for(x=0; x<c2; x++)
           {
           	  if (!(sBus[x].bus_type==1))
              for(y=0; y<sBus[x].genno; y++)
              {
              if (sBus[x].mgenstatus[y]==2){
                  temk[t]=gen[n1]-sBus[x].Genmax[y];
                  if (!(sBus[x].genb[y].cstatus==0)) temk[t]=temk[t]+sBus[x].genb[y].contract;
                  t=t+1;

                  }
              if (sBus[x].mgenstatus[y]==3){
              		 temk[t]=-gen[n1];
                   t=t+1;

                  }
             n1=n1+1;
           }
           }


    n1=0;
      for(x=0; x<c2; x++)
           {
           	  if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
               {
              if (sBus[x].dem.dmstatus==2){

              		temk[t]=dem[n1]-sBus[x].dem.max1;
                  if (!(sBus[x].dem.cstatus==0))
                  {
                   if (sBus[dv11[x]].dem.dcontract>sBus[dv11[x]].dem.bdem[daycount])
                   temk[t]=temk[t]+sBus[x].dem.dcontract;
                   if (sBus[dv11[x]].dem.dcontract<sBus[dv11[x]].dem.bdem[daycount])
                   temk[t]=temk[t]+sBus[x].dem.bdem[daycount];
                  }
                  t=t+1;
                  if ((sBus[x].dem.cstatus==0))temk[t]=temk[t]+sBus[x].dem.bdem[daycount];
                  }
              if (sBus[x].dem.dmstatus==3){
              		 temk[t]=sBus[x].dem.min1-dem[n1];
                   if (!(sBus[x].dem.cstatus==0)) temk[t]=temk[t]-sBus[x].dem.dcontract;
                   t=t+1;

                  }
             n1=n1+1;
           }
           }


      }

void jacobian2(int c0, int c1, int c2, double temk[MAX],double nv1[MAX][8],  int c3,double dv1[MAX][9], int dv11[MAX], int daycount )
	{
   	int x,y,t,n1;

      t=0;
      double n,n11,nt1;
      for (x=0; x<c0; x++)
          {

           if (nv1[x][6]==0)
           n=nv1[x][1]+2*nv1[x][2]*gen[x];
           if (nv1[x][6]==1)
           n=nv1[x][1]+2*nv1[x][2]*(gen[x]+nv1[x][7]);
           n11=0;

           if (nv1[x][3]==2)
            {

           	n11=glambda[x];


            }
           if (nv1[x][3]==3)n11=-glambda[x];
           for (y=0; y<c2; y++)
                    {

                    n11=n11+r[x][c3+c0+c2+y-1]*blambda[y];

                    }


          temk[t]=n+n11;
          t=t+1;
           }

       for (x=0; x<c3; x++)
          {

           if (dv1[x][6]==0)
           n=-1*(sBus[dv11[x]].dem.B[daycount]+4*sBus[dv11[x]].dem.C[daycount]*(dem[x]+sBus[dv11[x]].dem.bdem[daycount]));
           if (dv1[x][6]==1)
            {
           if (sBus[dv11[x]].dem.dcontract>sBus[dv11[x]].dem.bdem[daycount])
           n=-1*(sBus[dv11[x]].dem.B[daycount]+4*sBus[dv11[x]].dem.C[daycount]*(dem[x]+dv1[x][7]));
           if (sBus[dv11[x]].dem.dcontract<sBus[dv11[x]].dem.bdem[daycount])
           n=-1*(sBus[dv11[x]].dem.B[daycount]+4*sBus[dv11[x]].dem.C[daycount]*(dem[x]+sBus[dv11[x]].dem.bdem[daycount]));
            }
           n11=0;

           if (dv1[x][3]==2)
            {

           	n11=dlambda[x];

            }
           if (dv1[x][3]==3)n11=-dlambda[x];
           for (y=0; y<c2; y++)
                    {

                    n11=n11+r[x+c0][c0+c2+y-1+c3]*blambda[y];

                    }


          temk[t]=n+n11;
          t=t+1;
           }


      for (x=0; x<c2-1; x++)
          {
           n=0;
           for (y=0; y<c2; y++)
           n=n+r[x+c0+c3][c0+c2+y-1+c3]*blambda[y];
           for (y=0; y<c1; y++)
           	{
            if (sLine[y].status==1)
            {
            n=n+m5[y][x]*flambda[y];
            }
            if (sLine[y].status==-1)
            {
            n=n-m5[y][x]*flambda[y];
            }
            }
           temk[t]=n;
           t=t+1;
           }


      for (x=0; x<c2; x++)
          {
            n=0;
            if (!(sBus[x].bus_type==1))
            {
            	for(y=0; y<sBus[x].genno; y++)
               	if(!(sBus[x].genb[y].cstatus==0)) n=n-sBus[x].genb[y].contract;
            }
            if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
            {
               if(!(sBus[x].dem.cstatus==0))
               {
               if (sBus[dv11[x]].dem.dcontract>sBus[x].dem.bdem[daycount])
               n=n+sBus[x].dem.dcontract;
               if (sBus[dv11[x]].dem.dcontract<sBus[x].dem.bdem[daycount])
               n=n+sBus[x].dem.bdem[daycount];
               }
              if((sBus[x].dem.cstatus==0)) n=n+sBus[x].dem.bdem[daycount];

            }
            for (y=0; y<c0; y++)n=n+r[c0+c2+x-1+c3][y]*gen[y];
            for (y=0; y<c3; y++)n=n+r[c0+c2+x-1+c3][y+c0]*dem[y];
            for (y=0; y<c2; y++)n=n+r[c0+c2+x-1+c3][c0+y+c3]*bangle[y];
            temk[t]=n;
            t=t+1;
          }

      for(x=0; x<c1; x++)
      	{
         	nt1=0;
         	if (sLine[x].status==1)
            	{

               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1+m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
            if (sLine[x].status==-1)
            	{
               	for (y=0; y<c2-1; y++)
                  	 nt1=nt1-m5[x][y]*bangle[y];
                       nt1=nt1-sLine[x].LineMax;
                       temk[t]=nt1;
                       t=t+1;

                 }
             }


      	n1=0;
      for(x=0; x<c2; x++)
           {
           	  if (!(sBus[x].bus_type==1))
              for(y=0; y<sBus[x].genno; y++)
              {
              if (sBus[x].mgenstatus[y]==2){
                  cout<<"bus no:"<<x<<"  genno:"<<n1<<" max violation"<<"\n";
              		temk[t]=gen[n1]-sBus[x].Genmax[y];
                  if (!(sBus[x].genb[y].cstatus==0)) temk[t]=temk[t]+sBus[x].genb[y].contract;
                  t=t+1;

                  }
              if (sBus[x].mgenstatus[y]==3){
              		 temk[t]=-gen[n1];
                   t=t+1;

                  }
             n1=n1+1;
           }
           }


    n1=0;
      for(x=0; x<c2; x++)
           {
           	  if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
               {
              if (sBus[x].dem.dmstatus==2){
                  cout<<"bus no:"<<x<<"demand max violation"<<"\n";
              		temk[t]=dem[n1]-sBus[x].dem.max1;
                  if (!(sBus[x].dem.cstatus==0))
                  {
                   if (sBus[dv11[x]].dem.dcontract>sBus[dv11[x]].dem.bdem[daycount])
                   temk[t]=temk[t]+sBus[x].dem.dcontract;
                   if (sBus[dv11[x]].dem.dcontract<sBus[dv11[x]].dem.bdem[daycount])
                   temk[t]=temk[t]+sBus[x].dem.bdem[daycount];
                  }
                  t=t+1;
                  if ((sBus[x].dem.cstatus==0))temk[t]=temk[t]+sBus[x].dem.bdem[daycount];
                  }
              if (sBus[x].dem.dmstatus==3){
              		 temk[t]=sBus[x].dem.min1-dem[n1];
                   if (!(sBus[x].dem.cstatus==0)) temk[t]=temk[t]-sBus[x].dem.dcontract;
                   t=t+1;

                  }
             n1=n1+1;
           }
           }


      }

void matrixmul(double temk[MAX], int dim)
	{
   	int x,y;
      double sum;
      for (y=0; y<dim; y++)
       	{
        sum=0;
        for (x=0; x<dim; x++)
        	sum=sum+nv[y][x]*temk[x];
        z[y]=sum;
        }


      }

void adjustcontrol(int c0, int c1, int c2, int c3)
      {
         int x,n1,y;

         int n2;
         for(x=0; x<c0; x++) gen[x]=gen[x]-z[x];
         for(x=0; x<c2-1; x++) bangle[x]=bangle[x]-z[c0+x];
			for(x=0; x<c2; x++) blambda[x]=blambda[x]-z[c0+c2+x-1];
         n1=0;
         for(x=0; x<c1; x++)
           {
             if (!(sLine[x].status==0)){
               flambda[x]=flambda[x]-z[c0+2*c2+n1-1];
               n1=n1+1;
               }}
         n1=0;
         n2=0;
         for(x=0; x<c2; x++)
           {
             if(!(sBus[x].bus_type==1))
             {
              for(y=0; y<sBus[x].genno; y++)
              {
             if ((sBus[x].mgenstatus[y]==2)||(sBus[x].mgenstatus[y]==3)){
               glambda[n2]=glambda[n2]-z[c0+2*c2+c3+n1-1];
               n1=n1+1;
               }
               n2=n2+1;
               }

      }       }

      }

void adjustcontrol1(int c0, int c1, int c2, int c3, int c4, int c5)
      {
         int x,n1,y;
         int n2;
         for(x=0; x<c0; x++) gen[x]=gen[x]-z[x];
         for(x=0; x<c4; x++) dem[x]=dem[x]-z[x+c0];
         for(x=0; x<c2-1; x++) bangle[x]=bangle[x]-z[c0+x+c4];
			for(x=0; x<c2; x++) blambda[x]=blambda[x]-z[c0+c2+x-1+c4];
         n1=0;
         for(x=0; x<c1; x++)
           {
             if (!(sLine[x].status==0)){
               flambda[x]=flambda[x]-z[c0+2*c2+n1-1+c4];
               n1=n1+1;
               }}
         n1=0;
         n2=0;
         for(x=0; x<c2; x++)
           {
             if(!(sBus[x].bus_type==1))
             {
              for(y=0; y<sBus[x].genno; y++)
              {
             if ((sBus[x].mgenstatus[y]==2)||(sBus[x].mgenstatus[y]==3)){
               glambda[n2]=glambda[n2]-z[c0+2*c2+c3+n1-1+c4];
               n1=n1+1;
               }
               n2=n2+1;
               }
               }
               }

          n1=0;
         n2=0;
         for(x=0; x<c2; x++)
           {
             if((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
             {

             if ((sBus[x].dem.dmstatus==2)||(sBus[x].dem.dmstatus==3)){
               dlambda[n2]=dlambda[n2]-z[c0+2*c2+c3+n1-1+c4+c5];
               n1=n1+1;
               }
               n2=n2+1;

               }
               }
        }


void kurmatrix(double nv1[MAX][8],int gencount, int linecount, int buscount, int linecount1)
	{
      int k,l,n1,n2,y;

   for (k=0; k<gencount; k++) r[k][k]=2*nv1[k][2];


   n1=0;
   for (k=0; k<buscount; k++)
       {
         if (!(sBus[k].bus_type==1))
         {
          for(y=0; y<sBus[k].genno; y++)
          	{
            r[gencount+buscount+k-1][n1]=-1;
          	r[n1][gencount+buscount+k-1]=-1;
          	n1=n1+1;
            }
          }}

   for (k=0; k<buscount; k++)
   for (l=0; l<buscount-1; l++)
   	{
      	r[gencount+buscount-1+k][gencount+l]=m4[k][l];
         r[gencount+l][gencount+buscount-1+k]=m4[k][l];
      }
  n1=0;
  for(k=0; k<linecount; k++)
  		{
        if (sLine[k].status==1)
          {
            for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1][gencount+l]=m5[k][l];
             r[gencount+l][gencount+2*buscount-1+n1]=m5[k][l];
              }
             n1=n1+1;
          }
         if (sLine[k].status==-1)
         	{
             for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1][gencount+l]=-m5[k][l];
             r[gencount+l][gencount+2*buscount-1+n1]=-m5[k][l];
              }
             n1=n1+1;
          }
       }

      n1=0;
      n2=0;
      for (k=0; k<buscount; k++)
         {
          if (!(sBus[k].bus_type==1))
          {
           for (y=0; y<sBus[k].genno; y++)
           	{
           if (sBus[k].mgenstatus[y]==2)
           	{

               r[gencount+2*buscount+linecount1+n2-1][n1]=1;
               r[n1][gencount+2*buscount+linecount1+n2-1]=1;
               n2=n2+1;

            }

           if (sBus[k].mgenstatus[y]==3)
           	{

               r[gencount+2*buscount+linecount1+n2-1][n1]=-1;
               r[n1][gencount+2*buscount+linecount1+n2-1]=-1;
               n2=n2+1;
            }

            n1=n1+1;
      }
     }
      }


   }

void kurmatrix1 (double nv1[MAX][8], double dv1[MAX][9], int gencount, int linecount, int buscount, int linecount1, int mgencount, int demcount)
	{
      int k,l,n1,n2,y;

   for (k=0; k<gencount; k++) r[k][k]=2*nv1[k][2];

   for (k=0; k<demcount; k++) r[k+gencount][k+gencount]=-2*dv1[k][2];
   n1=0;
   for (k=0; k<buscount; k++)
       {
         if (!(sBus[k].bus_type==1))
         {
          for(y=0; y<sBus[k].genno; y++)
          	{
            r[gencount+buscount+k-1+demcount][n1]=-1;
          	r[n1][gencount+buscount+k-1+demcount]=-1;
          	n1=n1+1;
            }
          }}

     for (k=0; k<buscount; k++)
       {
         if ((sBus[k].bus_type==1)||(sBus[k].bus_type==3))
         {
            r[gencount+buscount+k-1+demcount][n1]=1;
          	r[n1][gencount+demcount+ buscount+k-1]=1;
          	n1=n1+1;

          }}



   for (k=0; k<buscount; k++)
   for (l=0; l<buscount-1; l++)
   	{
      	r[gencount+buscount-1+k+demcount][gencount+l+demcount]=m4[k][l];
         r[gencount+l+demcount][gencount+buscount-1+k+demcount]=m4[k][l];
      }
  n1=0;
  for(k=0; k<linecount; k++)
  		{
        if (sLine[k].status==1)
          {
            for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1+demcount][gencount+l+demcount]=m5[k][l];
             r[gencount+l+demcount][gencount+2*buscount-1+n1+demcount]=m5[k][l];
              }
             n1=n1+1;
          }
         if (sLine[k].status==-1)
         	{
             for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1+demcount][gencount+l+demcount]=-m5[k][l];
             r[gencount+l+demcount][gencount+2*buscount-1+n1+demcount]=-m5[k][l];
              }
             n1=n1+1;
          }
       }

      n1=0;
      n2=0;
      for (k=0; k<buscount; k++)
         {
          if (!(sBus[k].bus_type==1))
          {
           for (y=0; y<sBus[k].genno; y++)
           	{
           if (sBus[k].mgenstatus[y]==2)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount][n1]=1;
               r[n1][gencount+2*buscount+linecount1+n2-1+demcount]=1;
               n2=n2+1;

            }

           if (sBus[k].mgenstatus[y]==3)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount][n1]=-1;
               r[n1][gencount+2*buscount+linecount1+n2-1+demcount]=-1;
               n2=n2+1;
            }

            n1=n1+1;
      }
     }
      }


   	n1=0;
      n2=0;
      for (k=0; k<buscount; k++)
         {
          if ((sBus[k].bus_type==1)||(sBus[k].bus_type==3))
          {

           if (sBus[k].dem.dmstatus==2)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount+mgencount][n1+gencount]=1;
               r[n1+gencount][gencount+2*buscount+linecount1+n2-1+demcount+mgencount]=1;
               n2=n2+1;

            }

           if (sBus[k].dem.dmstatus==3)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount+mgencount][n1+gencount]=-1;
               r[n1+gencount][gencount+2*buscount+linecount1+n2-1+demcount+mgencount]=-1;
               n2=n2+1;
            }

            n1=n1+1;

     }
      }


   }

void kurmatrix2 (double nv1[MAX][8], double dv1[MAX][9], int gencount, int linecount, int buscount, int linecount1, int mgencount, int demcount)
	{
      int k,l,n1,n2,y;

   for (k=0; k<gencount; k++) r[k][k]=2*nv1[k][2];

   for (k=0; k<demcount; k++) r[k+gencount][k+gencount]=-4*dv1[k][2];
   n1=0;
   for (k=0; k<buscount; k++)
       {
         if (!(sBus[k].bus_type==1))
         {
          for(y=0; y<sBus[k].genno; y++)
          	{
            r[gencount+buscount+k-1+demcount][n1]=-1;
          	r[n1][gencount+buscount+k-1+demcount]=-1;
          	n1=n1+1;
            }
          }}

     for (k=0; k<buscount; k++)
       {
         if ((sBus[k].bus_type==1)||(sBus[k].bus_type==3))
         {
            r[gencount+buscount+k-1+demcount][n1]=1;
          	r[n1][gencount+demcount+ buscount+k-1]=1;
          	n1=n1+1;

          }}



   for (k=0; k<buscount; k++)
   for (l=0; l<buscount-1; l++)
   	{
      	r[gencount+buscount-1+k+demcount][gencount+l+demcount]=m4[k][l];
         r[gencount+l+demcount][gencount+buscount-1+k+demcount]=m4[k][l];
      }
  n1=0;
  for(k=0; k<linecount; k++)
  		{
        if (sLine[k].status==1)
          {
            for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1+demcount][gencount+l+demcount]=m5[k][l];
             r[gencount+l+demcount][gencount+2*buscount-1+n1+demcount]=m5[k][l];
              }
             n1=n1+1;
          }
         if (sLine[k].status==-1)
         	{
             for (l=0; l<buscount-1; l++)
             {
             r[gencount+2*buscount-1+n1+demcount][gencount+l+demcount]=-m5[k][l];
             r[gencount+l+demcount][gencount+2*buscount-1+n1+demcount]=-m5[k][l];
              }
             n1=n1+1;
          }
       }

      n1=0;
      n2=0;
      for (k=0; k<buscount; k++)
         {
          if (!(sBus[k].bus_type==1))
          {
           for (y=0; y<sBus[k].genno; y++)
           	{
           if (sBus[k].mgenstatus[y]==2)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount][n1]=1;
               r[n1][gencount+2*buscount+linecount1+n2-1+demcount]=1;
               n2=n2+1;

            }

           if (sBus[k].mgenstatus[y]==3)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount][n1]=-1;
               r[n1][gencount+2*buscount+linecount1+n2-1+demcount]=-1;
               n2=n2+1;
            }

            n1=n1+1;
      }
     }
      }


   	n1=0;
      n2=0;
      for (k=0; k<buscount; k++)
         {
          if ((sBus[k].bus_type==1)||(sBus[k].bus_type==3))
          {

           if (sBus[k].dem.dmstatus==2)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount+mgencount][n1+gencount]=1;
               r[n1+gencount][gencount+2*buscount+linecount1+n2-1+demcount+mgencount]=1;
               n2=n2+1;

            }

           if (sBus[k].dem.dmstatus==3)
           	{

               r[gencount+2*buscount+linecount1+n2-1+demcount+mgencount][n1+gencount]=-1;
               r[n1+gencount][gencount+2*buscount+linecount1+n2-1+demcount+mgencount]=-1;
               n2=n2+1;
            }

            n1=n1+1;

     }
      }

   }


int terminate(int dim)
    {
    	int x,t;
      t=0;
      for (x=0; x<dim; x++)

      	if ((z[x]>=0.001)||(z[x]<=-0.001))
         { t=t+1;

         }

     if (!(t==0)) return 1;
     	else return 0;
     }

 void kurm1(int c0)
 	{
   	int x,y;
      for (y=0; y<c0; y++)
      	for (x=0; x<sBus[y].con_no; x++)
         	{
            	if (y<sBus[y].Con[x].bus_no) m1[y][sBus[y].Con[x].line_no]=1;
                  else m1[y][sBus[y].Con[x].line_no]=-1;

            }

   }

void kurm1l(int c0)
 	{
   	int x,y;
      for (y=0; y<c0; y++)
      	for (x=0; x<sBus[y].con_no; x++)
         	{
               if (flw[sBus[y].Con[x].line_no]>=0)
               {
            	if (y<sBus[y].Con[x].bus_no) m1[y][sBus[y].Con[x].line_no]=1+0.5*sLine[sBus[y].Con[x].line_no].lc;
                  else m1[y][sBus[y].Con[x].line_no]=-1+0.5*sLine[sBus[y].Con[x].line_no].lc;
               }
               else
               {
               if (y<sBus[y].Con[x].bus_no) m1[y][sBus[y].Con[x].line_no]=1-0.5*sLine[sBus[y].Con[x].line_no].lc;
                  else m1[y][sBus[y].Con[x].line_no]=-1-0.5*sLine[sBus[y].Con[x].line_no].lc;

               }

            }

   }
 void kurm2(int c1)
    {
    	int y;

      for(y=0; y<c1; y++) m2[y][y]=sLine[y].suspect;

    }

 void kurm3(int c1)
 		{
      	int y;

         for (y=0; y<c1; y++)
         	{

               if((!(sLine[y].Busno1==0))&&(!(sLine[y].Busno2==0))&&(sLine[y].Busno2<sLine[y].Busno1))
                  {
                  	m3[y][sLine[y].Busno2-1]=-1;
                     m3[y][sLine[y].Busno1-1]=1;

                  }
                if((!(sLine[y].Busno1==0))&&(!(sLine[y].Busno2==0))&&(sLine[y].Busno2>sLine[y].Busno1))
                  {
                  	m3[y][sLine[y].Busno2-1]=1;
                     m3[y][sLine[y].Busno1-1]=-1;

                  }
               if (sLine[y].Busno1==0)m3[y][sLine[y].Busno2-1]=1;
               if (sLine[y].Busno2==0)m3[y][sLine[y].Busno1-1]=1;
            }

    }

void kurara(int c0,int c1)

      {
        int x,y,z;
        double sum;

        for (y=0; y<c1; y++)
   	  for (x=0; x<c0-1; x++)
   		{
        sum=0;
        for (z=0; z<c1; z++)
        	sum=sum+m2[y][z]*m3[z][x];
        m5[y][x]=sum;
          }
      }

void kurm4(int c0, int c1)
     {
     	  int x,y,z;
        double sum;

        kurara(c0,c1);

        for (y=0; y<c0; y++)
   	  for (x=0; x<c0-1; x++)
   		{
        sum=0;
        for (z=0; z<c1; z++)
        	sum=sum+m1[y][z]*m5[z][x];
        m4[y][x]=sum;

        }
     }

void opf(int c0, int c1)
    {
    	int y,x;
      double sum;
       for (y=0; y<c1; y++)
         {
         	sum=0;
          	  for (x=0; x<c0-1; x++)
                sum=sum+m5[y][x]*bangle[x];
        		flw[y]=sum;
           }

       }

void opf1(int c0, int c1, int daycount)
    {
    	int y,x;
      double sum;
       for (y=0; y<c1; y++)
         {
         	sum=0;
          	  for (x=0; x<c0-1; x++)
                sum=sum+m5[y][x]*bangle[x];
        		flw[y]=sum;
           }
       for (y=0; y<c1; y++)
            {
            if (flw[y]<0)
       		loss[y]=flw[y]*(-sLine[y].lc);
            else
            loss[y]=flw[y]*sLine[y].lc;
            }


          sum=0;
          for (y=0; y<c1; y++){
           sum=sum+loss[y];

            }
       lost[choice][daycount]=sum;
       }



void initr(int dim)
	{
   	int x,y;

      for (y=0; y<dim; y++)
         for (x=0; x<dim; x++) r[y][x]=0;
   }


/* ESTIMATION OF PRICES          */

void estpriceg(int buscount,int daycount, ofstream& oput)
  {
  	int x,y,z;


   x=0;
   for (y=0; y<buscount; y++)
      {
      	if (!(sBus[y].bus_type==1))
           for (z=0; z<sBus[y].genno; z++)
            {
              price[x]= sBus[y].genb[z].B+ 2*sBus[y].genb[z].C*gen[x];
              x=x+1;
            }
      }


    oput<<"\n";
    oput<<"GENERATOR SELL PRICES FOR HOUR "<<daycount<<"\n";
    x=0;
    for (y=0; y<buscount; y++)
    	{
        if (!(sBus[y].bus_type==1))
         for(z=0; z<sBus[y].genno; z++)
        	{

            oput<<" Genarator"<<x<<" Sell Price:	"<<price[x]<<"\n";
            x=x+1;
         }
        }

}
void estavgsprice(int gencount, int daycount)
  {
     int x;
     double sum1,sum2;
     sum1=0;
     sum2=0;
     for(x=0; x<gencount; x++)
     {
      sum1=sum1+gen[x]*price[x];
      sum2=sum2+gen[x];
     }
     avgsprice[choice][daycount]=sum1/sum2;
     }

void estavgbprice1 (int buscount,int daycount)
{
     int x;
     double sum1, sum2;
     sum1=0;
     sum2=0;
     for(x=0; x<buscount; x++)
     {
      if (sBus[x].rdum==0)
      sum1=sum1+sBus[x].Load[daycount]*admprice;
      else
      sum1=sum1+sBus[x].Load[daycount]*(1.097)*admprice;
      sum2=sum2+sBus[x].Load[daycount];
     }
     avgbprice[choice][daycount]=sum1/sum2;


   }

void estpriced(int buscount,ofstream& outl, int daycount, double dv1[MAX][9])
  {
  	int x,y;


   x=0;
   for (y=0; y<buscount; y++)
      {
      	if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

            {
              if (sBus[y].dem.cstatus==0)
              priced[x]= dv1[x][1]+ 2*dv1[x][2]*(dem[x]+sBus[y].dem.bdem[daycount]);
              if (!(sBus[y].dem.cstatus==0))
              priced[x]= dv1[x][1]+ 2*dv1[x][2]*(dem[x]+sBus[y].dem.dcontract);
              x=x+1;
            }
      }


    outl<<"\n";
    outl<<"CONSUMER BUY PRICES FOR HOUR"<<daycount<<"\n";

    x=0;
    for (y=0; y<buscount; y++)
    	{
        if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

        	{

            outl<<"Demand"<<x<<" Price:	"<<priced[x]<<"\n";




            x=x+1;
         }
        }

   }

void estavgbuyprice12(int buscount,int daycount)
{
     int x;
     double sum1, sum2,sum3, sum4;
    sum1=0;
     sum2=0;
     for(x=0; x<buscount; x++)
     {

      sum1=sum1+(dem[x]+sBus[x].dem.bdem[daycount])*priced[x];
      sum2=sum2+(dem[x]+sBus[x].dem.bdem[daycount]);
     }
     avgbprice[choice][daycount]=sum1/sum2;
     if (choice==1)
     {
     sum1=0;
     sum2=0;
     sum3=0;
     sum4=0;
     for(x=0; x<buscount; x++)
     {
      if (sBus[x].rdum==0)
      {
      sum1=sum1+(dem[x]+sBus[x].dem.bdem[daycount])*priced[x];
      sum2=sum2+(dem[x]+sBus[x].dem.bdem[daycount]);
      }
      if (sBus[x].rdum==1)
      {
      sum3=sum3+(dem[x]+sBus[x].dem.bdem[daycount])*priced[x];
      sum4=sum4+(dem[x]+sBus[x].dem.bdem[daycount]);
      }
     }
     avgbprice1[0][daycount]=sum1/sum2;
     avgbprice1[1][daycount]=sum3/sum4;
    }
    }

void estdbprice(int buscount, ofstream& outl, int daycount, double dv1[MAX][9])
  {
  	int x,y;

   double sum1,sum2;
   x=0;
   for (y=0; y<buscount; y++)
      {
      	if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

            {
              if (sBus[y].dem.cstatus==0)
              dbprice[x]= dv1[x][1]+ 4*dv1[x][2]*(dem[x]+sBus[y].dem.bdem[daycount]);
              if (!(sBus[y].dem.cstatus==0))
              dbprice[x]= dv1[x][1]+ 2*dv1[x][2]*(dem[x]+sBus[y].dem.dcontract);
              x=x+1;
            }
      }


    outl<<"PRICES PAID BY DISTRIBUTORS AT HOUR"<<daycount<<"\n";

    x=0;
    for (y=0; y<buscount; y++)
    	{
        if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

        	{

            outl<<"Demand"<<x<<" Price:	"<<dbprice[x]<<"\n";

     	       x=x+1;
         }
        }



    sum1=0;
    sum2=0;
     for(x=0; x<buscount; x++)
     {
      sum1=sum1+(dem[x]+sBus[x].dem.bdem[daycount])*dbprice[x];
      sum2=sum2+(dem[x]+sBus[x].dem.bdem[daycount]);
     }
     avgdbprice[daycount]=sum1/sum2;
    }


/*   ESTIMATION OF PROFITS AND CONSUMER SURPLUS   */

void estprofit (int buscount,int daycount,ofstream& oput)
	{
   	int x,y,z;

      x=0;
      for (y=0; y<buscount; y++)
      {
      	if (!(sBus[y].bus_type==1))
          for(z=0; z<sBus[y].genno; z++)
         	{
              if (sBus[y].genb[z].cstatus==0)
              profit[x]= price[x]*gen[x]-(sBus[y].genb[z].A+sBus[y].genb[z].B*gen[x]+ sBus[y].genb[z].C*gen[x]*gen[x]);
              if (!(sBus[y].genb[z].cstatus==0))
              profit[x]= price[x]*gen[x]+sBus[y].genb[z].cprice*sBus[y].genb[z].contract-(sBus[x].genb[z].A+ sBus[y].genb[z].B*(gen[x]+sBus[y].genb[z].contract)+ sBus[y].genb[z].C*pow((gen[x]+sBus[y].genb[z].contract),2));
              x=x+1;
            }
      }

    oput<<"\n";
    oput<<"PROFITS FOR HOUR"<<daycount<<"\n";
    x=0;
    for (y=0; y<buscount; y++)
    	{
        if (!(sBus[y].bus_type==1))
         for(z=0; z<sBus[y].genno; z++)
        	{

            oput<<" Generator "<<x <<" Profit:	"<<profit[x]<<"\n";
            x=x+1;
         }
       }
    }

 void estcsurplus (int buscount,int daycount, ofstream& outl)
	{
   	int x,y;
      x=0;
      for (y=0; y<buscount; y++)
      {
      	if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

         	{

              if (sBus[y].rdum==0)
              csurplus[x]= (sBus[y].dem.B[daycount]*(sBus[y].Load[daycount])+ sBus[y].dem.C[daycount]*pow((sBus[y].Load[daycount]),2))-admprice*(sBus[y].Load[daycount]);
              else
              csurplus[x]= (sBus[y].dem.B[daycount]*(sBus[y].Load[daycount])+ sBus[y].dem.C[daycount]*pow((sBus[y].Load[daycount]),2))-(1.097)*admprice*(sBus[y].Load[daycount]);
              x=x+1;
            }
      }

    outl<<"\n";
    outl<<"CONSUMER SURPLUS FOR HOR"<<daycount<<"\n";
    x=0;
    for (y=0; y<buscount; y++)
    	{
        if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

        	{

            outl<<" Demand "<<x <<"Consumer Surplus:	"<<csurplus[x]<<"\n";
            x=x+1;
         }
        }
    }

void estcsurplus12 (int buscount, ofstream& outl, int daycount)
	{
   	int x,y;
      x=0;
      for (y=0; y<buscount; y++)
      {
      	if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

         	{
              if (sBus[y].dem.cstatus==0)
              {

              csurplus[x]= (sBus[y].dem.B[daycount]*(dem[x]+sBus[y].dem.bdem[daycount])+ sBus[y].dem.C[daycount]*pow((dem[x]+sBus[y].dem.bdem[daycount]),2))-priced[x]*(dem[x]+sBus[y].dem.bdem[daycount]);

              }
              if (!(sBus[y].dem.cstatus==0))
              csurplus[x]= (sBus[y].dem.B[daycount]*(dem[x]+sBus[y].dem.dcontract)+ sBus[y].dem.C[daycount]*pow((dem[x]+sBus[y].dem.dcontract),2))-(priced[x]*dem[x]+sBus[y].dem.dcprice*sBus[y].dem.dcontract);
              x=x+1;
            }
      }

    outl<<"\n";
    outl<<"CONSUMER SURPLUS FOR HOUR"<<daycount<<"\n";
    x=0;
    for (y=0; y<buscount; y++)
    	{
        if ((sBus[y].bus_type==1)||(sBus[y].bus_type==3))

        	{

            outl<<" Demand "<<x <<" Consumer Surplus:	"<<csurplus[x]<<"\n";
            x=x+1;
         }
        }
    }

void estdprofit (int buscount,ofstream& outl, int daycount)
	{
   	int x,y;

      for (x=0; x<buscount; x++)
      {
             /*if (sBus[y].genb[z].cstatus==0)*/


              dprofit[x]= priced[x]*(dem[x]+sBus[x].dem.bdem[daycount])-dbprice[x]*(dem[x]+sBus[x].dem.bdem[daycount]);



      }
        outl<<"\n";
    outl<<"DISTRIBUTOR PROFITS AT HOUR"<<daycount<<"\n";

    for (y=0; y<buscount; y++)
    	{


            outl<<"Distributor "<<y<<" Profit:	"<<dprofit[y]<<"\n";


        }
    }


/* ESTIMATION OF HOURLY TOTAL WELAFRE VARIABLES */

void estcsurplustot(int buscount, int demcount, int daycount)
	{
    int x;
    csurplustot[choice][daycount]=0;
    for (x=0; x<demcount; x++)
    	{
      	csurplustot[choice][daycount]=csurplustot[choice][daycount]+csurplus[x];

     }

     csurplustot1[choice][daycount]=0;
     csurplustot2[choice][daycount]=0;
     for (x=0; x<buscount; x++)
    	{
         if (sBus[x].rdum==0)
      	csurplustot1[choice][daycount]=csurplustot1[choice][daycount]+csurplus[x];
         else
         csurplustot2[choice][daycount]=csurplustot2[choice][daycount]+csurplus[x];

     }

    }
void estdemt1(int buscount)
	{
   	int x,y;
      double sum;
      for (y=0; y<24; y++)
      {
      demt[0][y]=0;
     	for(x=0; x<buscount; x++)
         demt[0][y]=demt[0][y]+sBus[x].Load[y];
      }
   sum=0;
  for (x=0; x<24; x++) sum=sum+demt[choice][x];
  ddemt[choice]=sum;
   }

void estdemt(int buscount, int daycount)
	{
   	int x;
      demt[choice][daycount]=0;
     	for(x=0; x<buscount; x++)
         demt[choice][daycount]=demt[choice][daycount]+dem[x]+sBus[x].dem.bdem[daycount];;
   }

void estproftot(int gencount, int daycount)
	{
   	int x;
      proftot[choice][daycount]=0;
      for (x=0; x<gencount; x++)
         proftot[choice][daycount]=proftot[choice][daycount]+profit[x];
  }
void estgentot(int gencount, int daycount)
	{
   int x;
   gentot[choice][daycount]=0;
       for (x=0; x<gencount; x++)
          gentot[choice][daycount]=gentot[choice][daycount]+gen[x];
    }

void estdproftot(int demcount, int daycount)
	{
   int x;
	dproftot[daycount]=0;
       for (x=0; x<demcount; x++)
         dproftot[daycount]=dproftot[daycount]+dprofit[x];
    }

void estreginc(int buscount, int gencount, int daycount)
{
  int x;
  double sum;
  sum=0;
  for (x=0; x<buscount; x++)
  {
  if (sBus[x].rdum==0)
   sum=sum+admprice*sBus[x].Load[daycount];
    else
   sum=sum+(1.097)*admprice*sBus[x].Load[daycount];
  }
  for (x=0; x<gencount; x++) sum=sum-gen[x]*price[x];
  reginc[daycount]=sum;
}

void estsocwelfare (int daycount)
{

  socwelfare[choice][daycount]=proftot[choice][daycount]+csurplustot[choice][daycount];
  if (choice==2)

  socwelfare[choice][daycount]=socwelfare[choice][daycount]+dproftot[daycount];


  }

void estdailytotals ()
{
  int x;
  double sum;
  sum=0;
  for (x=0; x<24; x++) sum=sum+gentot[choice][x];
  dgentot[choice]=sum;
  sum=0;
  for (x=0; x<24; x++) sum=sum+demt[choice][x];
  ddemt[choice]=sum;
  sum=0;
  for (x=0; x<24; x++)
  {
   lost[choice][x]=gentot[choice][x]- demt[choice][x];
   sum=sum+lost[choice][x];
  }
  dlost[choice]=sum;

  sum=0;
  for (x=0; x<24; x++) sum=sum+proftot[choice][x];
  dgproftot[choice]=sum;
  sum=0;
  for (x=0; x<24; x++) sum=sum+csurplustot[choice][x];
  dcsurplustot[choice]=sum;
  sum=0;
  for (x=0; x<24; x++) sum=sum+socwelfare[choice][x];
  dsocwelfare[choice]=sum;
  if (choice==2)
  {
  sum=0;
  for (x=0; x<24; x++) sum=sum+dproftot[x];
  ddproftot=sum;
  }

   sum=0;
  for (x=0; x<24; x++) sum=sum+csurplustot1[choice][x];
  dcsurplustot1[choice]=sum;
  sum=0;
  for (x=0; x<24; x++) sum=sum+csurplustot2[choice][x];
  dcsurplustot2[choice]=sum;

  }

/* ESTIMATION OF ADMINSITERED PRICE IN ROUTINE O */

void determine_admprice(int buscount) {
 int x,y,z,w;
 double s1,s2,s3,s4,k;


    s2=0;
    s4=0;
   for (z=0; z<24; z++)

   {



        for (y=0; y<buscount; y++)
        {
         k=1;
          for (w=0; w<24; w++)
          {

          for (x=0; x<buscount; x++)
           {
            if ((!(x==y))||(!(w==z))) k=k*sBus[x].dem.C[w];
           }
           }

          s1=sBus[y].dem.B[z]*k;
          s2=s2+s1;
         }




         for (y=0; y<buscount; y++)
        {
         k=1;
          for (w=0; w<24; w++)
          {
          for (x=0; x<buscount; x++)
           {
            if ((!(x==y))||(!(w==z))) k=k*sBus[x].dem.C[w];
           }

           }
           if (sBus[y].rdum==1) k=k*(1.097);
           s4=s4+k;
          }

         }


         s3=ddemt[0]*2;

         for (w=0; w<24; w++)
         for (x=0; x<buscount; x++) s3=s3*sBus[x].dem.C[w];

         admprice=(s2+s3)/s4;
         for (z=0; z<24; z++)
         {
           for (y=0; y<30; y++)
           {
             if (sBus[y].rdum==0) k=1;
             	else k=1.097;
             sBus[y].Load[z]=(admprice*k-sBus[y].dem.B[z])/(2*sBus[y].dem.C[z]);
           }

          }

         }

/* ROUTINES FOR EACH CASE */

void apr(double nv1[MAX][8],double tempr[MAX])
 {

  int x,y;
  int n1,n2,n3,nk11,nk2;




  int daycount,counter,dim;
  double ara;

  for(x=0; x<buscount; x++)
   	{
     if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
          sBus[x].mgenstatus[y]=1;
         }
		if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        sBus[x].dem.dmstatus=1;

         }
  for(x=0; x<linecount; x++)
   	sLine[x].linestatus=1;

  estdemt1(buscount);
  determine_admprice(buscount);
  kurm1(buscount);
  kurm2(linecount);
  kurm3(linecount);
  kurm4(buscount,linecount);
  ofstream sout("aprdailytotal.txt");
  ofstream outfile("aprhourly.txt");
   for (daycount=0; daycount<24; daycount++)
  {
  outfile<<"hour :	"<<daycount<<"\n";
  outfile<<"load profiles in hour	"<<daycount<<"\n";

      for (x=0; x<buscount; x++)
      {

       outfile<<"Bus no:"<<x<<"   Load:	"<<sBus[x].Load[daycount]<<"\n";
      }

  estdemt(buscount,daycount);

  mgencount=0;
  linecount1=0;
  initialguess(gencount,linecount,buscount);

  counter=0;

  do
  {
   if (counter==0) flag=0;
   else flag=1;

   do
   {

   dim=gencount+2*buscount-1+mgencount+linecount1;
   clrscr();
   initr(dim);
   kurmatrix(nv1,gencount,linecount,buscount,linecount1);

   matrixoper(dim,gencount,buscount);

   do
      {
   n2=0;
   jacobian(gencount,linecount,buscount,tempr,nv1,daycount);
   matrixmul(tempr,dim);
   adjustcontrol(gencount,linecount,buscount,linecount1);
   n2=terminate(dim);
   counter=counter+1;
   }
   while (n2==1);
   if (flag==0)
   {
   kurara(buscount,linecount);
   opf(buscount,linecount);
   }
   else
   {
   kurara(buscount,linecount);
   opf1(buscount,linecount,daycount);
   }

   linecount1=0;
  for(y=0; y<dim; y++)
  for (x=0; x<dim; x++) r[y][x]=0;

   nk2=1;
   n3=0;
   n1=0;

       for (x=0; x<buscount; x++)
       	{
           if (!(sBus[x].bus_type==1))
           for(y=0; y<sBus[x].genno; y++)
           {
           	if(!(sBus[x].genb[y].cstatus==0)) ara=gen[n1]+sBus[x].genb[y].contract;
            	else ara=gen[n1];
           if ((ara>sBus[x].Genmax[y])&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))
            	{


               	nv1[n1][3]=2;
                  sBus[x].mgenstatus[y]=2;
                  mgencount=mgencount+1;
                  n3=n3+1;
                  nk2=0;
               }
            if ((gen[n1]<0)&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))

            	{

               	nv1[n1][3]=3;
                  sBus[x].mgenstatus[y]=3;
                  mgencount=mgencount+1;
                  n3=n3+1;
                  nk2=0;
               }
               n1=n1+1;
              }
             }




            for (x=0; x<linecount; x++)
         	{
              if ((flw[x]>sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
              	{
               	sLine[x].status=1;
                n3=n3+1;
               }
              if ((flw[x]<-sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
               {
               	sLine[x].status=-1;
                n3=n3+1;
               }
               if ((sLine[x].status==1)||(sLine[x].status==-1)) linecount1=linecount1+1;
              }

     if (!(n3==0))
     {
     cout<<"violation"<<"\n";

     }
      }

   while(!(n3==0));
   if (flag==0)
   {
    kurm1l(buscount);
    kurm4(buscount,linecount);
    }

   }
   while (flag==0);


   clrscr();


   outfile<<" No of Iteration: "<<counter<<"\n";


   clrscr();
   nk11=0;
   for (x=0; x<linecount; x++)
   if((sLine[x].status==1)||(sLine[x].status==-1))nk11=nk11+1;
   nk2=0;
   for (x=0; x<buscount; x++)
   {
    if (!(sBus[x].bus_type==1))
     for(y=0; y<sBus[x].genno; y++)
     {
   	if((sBus[x].mgenstatus[y]==2)||(sBus[x].mgenstatus[y]==3))nk2=nk2+1;
      } }

   outfile<<"Number of line flow violations:"<<nk11<<"\n";
   outfile<<"Number of generator limit violations:"<<nk2<<"\n";


   clrscr();
   outfile<<"\n";


   outfile<<" HOURLY OUTPUT AT "<<daycount<<"\n";
   outfile<<"GENERATOR OUTPUT AT HOUR "<<daycount<<" \n";

   for (x=0; x<gencount; x++)
   	{
         outfile<<" generator "<<x<<"   output:	"<<gen[x]<<"\n";
               }

  outfile<<"\n";

  outfile<<"FLOWS:"<<"\n";
  for (x=0; x<linecount; x++)
  	{
   	if (sLine[x].Busno1<sLine[x].Busno2)
          {
          outfile<<flw[x]<<"\n";
          }
      if (sLine[x].Busno1>sLine[x].Busno2)
          {
          outfile<<flw[x]<<"\n";
      }
      }
  outfile<<"\n";
  outfile<<"LINE LOSSES AT HOUR "<<daycount<<"\n";
  for (x=0; x<linecount; x++)
  	{
   	if (sLine[x].Busno1<sLine[x].Busno2)
          {
          outfile<<loss[x]<<"\n";

          }
      if (sLine[x].Busno1>sLine[x].Busno2)
          {
          outfile<<loss[x]<<"\n";

       }
      }
  outfile<<"\n";
  cout<<"BUS ANGLES:"<<"\n";
  outfile<<"BUS ANGLES:"<<"\n";
  for (x=1; x<buscount; x++)
        {
        cout<<"bus angle "<<x<<"   ;"<<bangle[x-1]<<"\n";
        outfile<<"bus angle "<<x<<"   ;"<<bangle[x-1]<<"\n";
        }


  outfile<<"\n";

  outfile<<"EQUALITY LAMBDAS:"<<"\n";
   for (x=0; x<buscount; x++)
        {
        outfile<<"bus lambda "<<x<<":	"<<blambda[x]<<"\n";

        }



 estpriceg(buscount,daycount,outfile);
 estavgsprice(gencount,daycount);
 estavgbprice1(buscount,daycount);
 estprofit(buscount,daycount, outfile);
 estcsurplus(buscount,daycount,outfile);
 estcsurplustot(buscount,demcount,daycount);
 estproftot(gencount, daycount);
 estdemt1(buscount);
 estgentot(gencount,daycount);
 estreginc(buscount, gencount,daycount);
 estsocwelfare (daycount);

 for (x=0; x<linecount; x++) sLine[x].status=0;
    for (x=0; x<buscount; x++)
    	{
      	if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
         for (y=0; y<sBus[x].genno; y++) sBus[x].mgenstatus[y]=1;

         }
  for(x=0; x<linecount; x++)
   	sLine[x].linestatus=1;

 outfile<<"---------------------------------------------------------";
 outfile<<"---------------------------------------------------------" ;
 outfile<<"---------------------------------------------------------"  ;
 }
   estdailytotals();
   sout<<"HOURLY TOTAL FOR EACH HOUR"<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"NOTE: Generation, Load and Loss variables are in MWh."<<"\n";
   sout<<"      Social Welfare, Profit, Consumer Surplus variables are in"<<"\n";
   sout<<"      100000 TL. Price variables are in 100000 TL/MWh."<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"TOTAL GENERATION     :"<<"\n";
   for (x=0; x<24; x++) sout<<gentot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOAD           :"<<"\n";
   for (x=0; x<24; x++) sout<<demt[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOSS           :"<<"\n";
   for (x=0; x<24; x++) sout<<lost[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL PROFITS        :"<<"\n";
   for (x=0; x<24; x++) sout<<proftot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS        :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot1[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN NON-PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot2[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL SOCIAL WELFARE       :"<<"\n";
   for (x=0; x<24; x++) sout<<socwelfare[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE SELL PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgsprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE BUy PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgbprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"*********************************************************"<<"\n";
   sout<<"							DAILY TOTAL                          "<<"\n";
   sout<<"GENERATION:						"<<dgentot[choice]<<"\n";
   sout<<"LOAD:	        					"<<ddemt[choice]<<"\n";
   sout<<"LOSS:								"<<dlost[choice]<<"\n";
   sout<<"PROFITS:							"<<dgproftot[choice]<<"\n";
   sout<<"CONSUMER SURPLUS:				"<<dcsurplustot[choice]<<"\n";
   sout<<"SOCIAL WELFARE:					"<<dsocwelfare[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN PRD:		"<<dcsurplustot1[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN NON-PRD:	"<<dcsurplustot2[choice]<<"\n";
   sout<<"ADMINISTRED PRICE IN PRD:		"<<admprice<<"\n";
   sout<<"ADMINISTRED PRICE IN NON-PRD:		"<<admprice*(1.097)<<"\n";
 outfile.close();
 sout.close();
 clrscr();
 }

void fcc(double nv1[MAX][8],double tempr[MAX],int dv11[MAX],double dv1[MAX][9])
{
  int x,y,nt1;
  int n1,n2,n3,nk11,nk2;




  int daycount,counter,dim;
  double ara;


  ofstream sout("fccdaily.txt");
  ofstream oput("fcchourly.txt");
  for(x=0; x<buscount; x++)
   	{
     if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
          sBus[x].mgenstatus[y]=1;
         }
		if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        sBus[x].dem.dmstatus=1;

         }
  for(x=0; x<linecount; x++)
  sLine[x].linestatus=1;
  cdemcount=0;
  mgencount=0;
  linecount1=0;
  kurm1(buscount);
  kurm2(linecount);
  kurm3(linecount);
  kurm4(buscount,linecount);
  for (daycount=0; daycount<24; daycount++ )
  {
   for (x=0; x<demcount; x++)
   	{
      	dv1[x][1]=sBus[dv11[x]].dem.B[daycount];
         dv1[x][2]=sBus[dv11[x]].dem.C[daycount];  }


  initialguess12(gencount,linecount,buscount,demcount);


  counter=0;

   do
  {
   if (counter==0) flag=0;
   else flag=1;

   do
   {

   dim=gencount+demcount+2*buscount-1+mgencount+linecount1+cdemcount;
   initr(dim);
   kurmatrix1(nv1, dv1, gencount,linecount,buscount,linecount1,mgencount,demcount);
   matrixoper12(dim,gencount,buscount,demcount);

   do
      {
   n2=0;

   jacobian1(gencount,linecount,buscount,tempr,nv1,demcount,dv1,dv11, daycount);



   matrixmul(tempr,dim);

   adjustcontrol1(gencount,linecount,buscount,linecount1, demcount, mgencount);
   n2=terminate(dim);


   counter=counter+1;
   }
   while (n2==1);
   if (flag==0)
   {
   kurara(buscount,linecount);
   opf(buscount,linecount);
   }
   else
   {
   kurara(buscount,linecount);
   opf1(buscount,linecount,daycount);
   }
   linecount1=0;

   for(y=0; y<dim; y++)
   	for (x=0; x<dim; x++) r[y][x]=0;

   nk2=1;
   n3=0;
   n1=0;

       for (x=0; x<buscount; x++)
       	{
           if (!(sBus[x].bus_type==1))
           for(y=0; y<sBus[x].genno; y++)
           {
           	if(!(sBus[x].genb[y].cstatus==0)) ara=gen[n1]+sBus[x].genb[y].contract;
            	else ara=gen[n1];
           if ((ara>sBus[x].Genmax[y])&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))
            	{


               	nv1[n1][3]=2;
                  sBus[x].mgenstatus[y]=2;
                  mgencount=mgencount+1;

                  n3=n3+1;
                  nk2=0;
               }
            if ((gen[n1]<0)&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))

            	{

               	nv1[n1][3]=3;
                  sBus[x].mgenstatus[y]=3;
                  mgencount=mgencount+1;

                  n3=n3+1;
                  nk2=0;
               }
               n1=n1+1;
              }
             }




            for (x=0; x<linecount; x++)
         	{
              if ((flw[x]>sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
              	{
               	sLine[x].status=1;

                  n3=n3+1;
               }
              if ((flw[x]<-sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
               {
               	sLine[x].status=-1;

                  n3=n3+1;
               }
               if ((sLine[x].status==1)||(sLine[x].status==-1)) linecount1=linecount1+1;
              }




   n1=0;

       for (x=0; x<buscount; x++)
       	{
           if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
           {
           	if(!(sBus[x].dem.cstatus==0)) ara=dem[n1]+sBus[x].dem.dcontract;
            	else ara=dem[n1];
           if ((ara>sBus[x].dem.max1)&&(nk2==1)&&(sBus[x].dem.dmstatus==1))
            	{


               	dv1[n1][3]=2;
                  sBus[x].dem.dmstatus=2;
                  cdemcount=cdemcount+1;

                  n3=n3+1;
                  nk2=0;
               }
            if ((ara<sBus[x].dem.min1)&&(nk2==1)&&(sBus[x].dem.dmstatus==1))

            	{

               	dv1[n1][3]=3;
                  sBus[x].dem.dmstatus=3;
                  cdemcount=cdemcount+1;


                  n3=n3+1;
                  nk2=0;
               }
               n1=n1+1;
              }
             }

     }
   while(!(n3==0));
   if (flag==0)
   {
    kurm1l(buscount);
     kurm4(buscount,linecount);
    }

   }
   while (flag==0);





   nk11=0;

   for (x=0; x<linecount; x++)
   if((sLine[x].status==1)||(sLine[x].status==-1))nk11=nk11+1;
   nk2=0;

   for (x=0; x<buscount; x++)
   {
    if (!(sBus[x].bus_type==1))
     for(y=0; y<sBus[x].genno; y++)
     {
   	if((sBus[x].mgenstatus[y]==2)||(sBus[x].mgenstatus[y]==3))nk2=nk2+1;
      } }

   nt1=0;
   for (x=0; x<buscount; x++)
   {
    if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))

     {
   	if((sBus[x].dem.dmstatus==2)||(sBus[x].dem.dmstatus==3))nt1=nt1+1;
      } }


   oput<<"VALUES FOR HOUR "<<daycount<<" \n";
   oput<<"Number of line flow violations:"<<nk11<<"\n";

   oput<<"Number of generator limit violations:"<<nk2<<"\n";

   oput<<"Number of demand limit violations:"<<nt1<<"\n";

   oput<<"\n";




   oput<<"GENERATOR OUTPUT AT HOUR "<<daycount<<" \n";
   for (x=0; x<gencount; x++)
   	{
         oput<<"Generator "<<x<<":	"<<gen[x]<<"\n";


      }


  oput<<"\n";
  oput<<"DEMAND OUTPUT AT HOUR "<<daycount<<" \n";

  for (x=0; x<demcount; x++)
  {
    oput<<"Demand "<<x<<":	"<<(dem[x]+sBus[dv11[x]].dem.bdem[daycount])<<"\n";
  }
  oput<<"\n";

  oput<<"FLOWS AT HOUR"<<daycount<<"\n";
  for (x=0; x<linecount; x++)oput<<flw[x]<<"\n";


   oput<<"\n";
   oput<<"LINE LOSSES:"<<"\n";
   for (x=0; x<linecount; x++)oput<<loss[x]<<"\n";
   oput<<"\n";
  oput<<"BUS ANGLES:"<<"\n";
  for (x=1; x<buscount; x++)
        {
        oput<<"bus angle "<<x<<":	"<<bangle[x-1]<<"\n";

        }


  oput<<"\n";

  oput<<"EQUALITY LAMBDAS:"<<"\n";
   for (x=0; x<buscount; x++)
        {
        oput<<"bus lambda "<<x<<":	"<<blambda[x]<<"\n";

        }





 estpriceg(buscount,daycount,oput);
 estavgsprice(gencount,daycount);
 estprofit(buscount,daycount, oput);
 estpriced(buscount,oput,daycount,dv1);
 estavgbuyprice12(buscount,daycount);
 estcsurplus12(buscount,oput,daycount);
 estdemt(buscount, daycount);
 estproftot(gencount,daycount);
 estgentot(gencount,daycount);
 estcsurplustot(buscount,demcount,daycount);
 estsocwelfare (daycount);

for (x=0; x<gencount; x++) nv1[x][3]=1;
for(x=0; x<buscount; x++) dv1[x][3]=1;
 for(x=0; x<buscount; x++)
   	{
     if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
          sBus[x].mgenstatus[y]=1;


         }

     if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        sBus[x].dem.dmstatus=1;

         }
 for (x=0; x<linecount; x++) sLine[x].status=0;
 cdemcount=0;
 mgencount=0;
 linecount1=0;
 oput<<"***********************************************************"<<"\n";
 oput<<"***********************************************************"<<"\n";




 };
  estdailytotals();
   sout<<"HOURLY TOTALS FOR FREE CONSUMER CASE"<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"NOTE: Generation, Load and Loss variables are in MWh."<<"\n";
   sout<<"      Social Welfare, Profit, Consumer Surplus variables are in"<<"\n";
   sout<<"      100000 TL. Price variables are in 100000 TL/MWh."<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"TOTAL GENERATION     :"<<"\n";
   for (x=0; x<24; x++) sout<<gentot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOAD           :"<<"\n";
   for (x=0; x<24; x++) sout<<demt[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOSS           :"<<"\n";
   for (x=0; x<24; x++) sout<<lost[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TTOTAL PROFITS        :"<<"\n";
   for (x=0; x<24; x++) sout<<proftot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS        :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot1[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN NON-PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot2[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL SOCIAL WELFARE       :"<<"\n";
   for (x=0; x<24; x++) sout<<socwelfare[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE SELL PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgsprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE BUY PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgbprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE BUY PRICE IN PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<avgbprice1[0][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE BUY PRICE IN NON-PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<avgbprice1[1][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"*********************************************************"<<"\n";
   sout<<"							DAILY TOTALS                          "<<"\n";
   sout<<"GENERATION:						"<<dgentot[choice]<<"\n";
   sout<<"LOAD:	        					"<<ddemt[choice]<<"\n";
   sout<<"LOSS:								"<<dlost[choice]<<"\n";
   sout<<"PROFITS:							"<<dgproftot[choice]<<"\n";
   sout<<"CONSUMER SURPLUS:				"<<dcsurplustot[choice]<<"\n";
   sout<<"SOCIAL WELFARE:					"<<dsocwelfare[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN PRD:		"<<dcsurplustot1[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN NON-PRD:	"<<dcsurplustot2[choice]<<"\n";

 oput.close();
 sout.close();
}

void dmc(double nv1[MAX][8],double tempr[MAX],int dv11[MAX],double dv1[MAX][9])
{

  int x,y,nt1;
  int n1,n2,n3,nk11,nk2;



  int daycount,counter,dim;
  double ara;

  ofstream sout("dmcdaily.txt");
  ofstream oput("dmchourly.txt");
  for(x=0; x<buscount; x++)
   	{
     if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
          sBus[x].mgenstatus[y]=1;
         }
		if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        sBus[x].dem.dmstatus=1;

         }
  for(x=0; x<linecount; x++)
  sLine[x].linestatus=1;
  cdemcount=0;
  mgencount=0;
  linecount1=0;
  kurm1(buscount);
  kurm2(linecount);
  kurm3(linecount);
  kurm4(buscount,linecount);
  for (daycount=0; daycount<24; daycount++ )
  {
   for (x=0; x<demcount; x++)
   	{
      	dv1[x][1]=sBus[dv11[x]].dem.B[daycount];
         dv1[x][2]=sBus[dv11[x]].dem.C[daycount];  }


  initialguess12(gencount,linecount,buscount,demcount);


  counter=0;

   do
  {
   if (counter==0) flag=0;
   else flag=1;

   do
   {

   dim=gencount+demcount+2*buscount-1+mgencount+linecount1+cdemcount;
   initr(dim);
   kurmatrix2(nv1, dv1, gencount,linecount,buscount,linecount1,mgencount,demcount);
   matrixoper12(dim,gencount,buscount,demcount);

   do
      {
   n2=0;

   jacobian2(gencount,linecount,buscount,tempr,nv1,demcount,dv1,dv11, daycount);



   matrixmul(tempr,dim);

   adjustcontrol1(gencount,linecount,buscount,linecount1, demcount, mgencount);
   n2=terminate(dim);


   counter=counter+1;
   }
   while (n2==1);
   if (flag==0)
   {
   kurara(buscount,linecount);
   opf(buscount,linecount);
   }
   else
   {
   kurara(buscount,linecount);
   opf1(buscount,linecount,daycount);
   }
   linecount1=0;

   for(y=0; y<dim; y++)
   	for (x=0; x<dim; x++) r[y][x]=0;

   nk2=1;
   n3=0;
   n1=0;

       for (x=0; x<buscount; x++)
       	{
           if (!(sBus[x].bus_type==1))
           for(y=0; y<sBus[x].genno; y++)
           {
           	if(!(sBus[x].genb[y].cstatus==0)) ara=gen[n1]+sBus[x].genb[y].contract;
            	else ara=gen[n1];
           if ((ara>sBus[x].Genmax[y])&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))
            	{


               	nv1[n1][3]=2;
                  sBus[x].mgenstatus[y]=2;
                  mgencount=mgencount+1;

                  n3=n3+1;
                  nk2=0;
               }
            if ((gen[n1]<0)&&(nk2==1)&&(sBus[x].mgenstatus[y]==1))

            	{

               	nv1[n1][3]=3;
                  sBus[x].mgenstatus[y]=3;
                  mgencount=mgencount+1;

                  n3=n3+1;
                  nk2=0;
               }
               n1=n1+1;
              }
             }




            for (x=0; x<linecount; x++)
         	{
              if ((flw[x]>sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
              	{
               	sLine[x].status=1;

                  n3=n3+1;
               }
              if ((flw[x]<-sLine[x].LineMax)&&(sLine[x].status==0)&&(nk2==1))
               {
               	sLine[x].status=-1;

                  n3=n3+1;
               }
               if ((sLine[x].status==1)||(sLine[x].status==-1)) linecount1=linecount1+1;
              }




   n1=0;

       for (x=0; x<buscount; x++)
       	{
           if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
           {
           	if(!(sBus[x].dem.cstatus==0)) ara=dem[n1]+sBus[x].dem.dcontract;
            	else ara=dem[n1];
           if ((ara>sBus[x].dem.max1)&&(nk2==1)&&(sBus[x].dem.dmstatus==1))
            	{


               	dv1[n1][3]=2;
                  sBus[x].dem.dmstatus=2;
                  cdemcount=cdemcount+1;

                  n3=n3+1;
                  nk2=0;
               }
            if ((ara<sBus[x].dem.min1)&&(nk2==1)&&(sBus[x].dem.dmstatus==1))

            	{

               	dv1[n1][3]=3;
                  sBus[x].dem.dmstatus=3;
                  cdemcount=cdemcount+1;


                  n3=n3+1;
                  nk2=0;
               }
               n1=n1+1;
              }
             }

     }
   while(!(n3==0));
   if (flag==0)
   {
    kurm1l(buscount);
     kurm4(buscount,linecount);
    }

   }
   while (flag==0);





   nk11=0;

   for (x=0; x<linecount; x++)
   if((sLine[x].status==1)||(sLine[x].status==-1))nk11=nk11+1;
   nk2=0;

   for (x=0; x<buscount; x++)
   {
    if (!(sBus[x].bus_type==1))
     for(y=0; y<sBus[x].genno; y++)
     {
   	if((sBus[x].mgenstatus[y]==2)||(sBus[x].mgenstatus[y]==3))nk2=nk2+1;
      } }

   nt1=0;
   for (x=0; x<buscount; x++)
   {
    if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))

     {
   	if((sBus[x].dem.dmstatus==2)||(sBus[x].dem.dmstatus==3))nt1=nt1+1;
      } }


   oput<<"VALUES FOR HOUR "<<daycount<<" \n";
   oput<<"Number of line flow violations:"<<nk11<<"\n";

   oput<<"Number of generator limit violations:"<<nk2<<"\n";

   oput<<"Number of demand limit violations:"<<nt1<<"\n";

   oput<<"\n";




   oput<<"GENERATOR OUTPUT AT HOUR "<<daycount<<" \n";
   for (x=0; x<gencount; x++)
   	{
         oput<<"Generator "<<x<<":	"<<gen[x]<<"\n";


      }


  oput<<"\n";
  oput<<"DEMAND OUTPUT AT HOUR "<<daycount<<" \n";

  for (x=0; x<demcount; x++)
  {
    oput<<"Demand "<<x<<":	"<<(dem[x]+sBus[dv11[x]].dem.bdem[daycount])<<"\n";
  }
  oput<<"\n";

  oput<<"FLOWS AT HOUR"<<daycount<<"\n";
  for (x=0; x<linecount; x++)oput<<flw[x]<<"\n";


   oput<<"\n";
   oput<<"LINE LOSSES:"<<"\n";
   for (x=0; x<linecount; x++)oput<<loss[x]<<"\n";
   oput<<"\n";
  oput<<"BUS ANGLES:"<<"\n";
  for (x=1; x<buscount; x++)
        {
        oput<<"bus angle "<<x<<":	"<<bangle[x-1]<<"\n";

        }


  oput<<"\n";

  oput<<"EQUALITY LAMBDAS:"<<"\n";
   for (x=0; x<buscount; x++)
        {
        oput<<"bus lambda "<<x<<":	"<<blambda[x]<<"\n";

        }





 estpriceg(buscount,daycount,oput);
 estavgsprice(gencount,daycount);
 estprofit(buscount,daycount, oput);
 estpriced(buscount,oput,daycount,dv1);
 estdbprice(buscount,oput,daycount, dv1);
 estavgbuyprice12(buscount,daycount);
 estcsurplus12(buscount,oput,daycount);
 estdprofit (buscount,oput,daycount);
 estdemt(buscount, daycount);
 estproftot(gencount,daycount);
 estdproftot(buscount, daycount);
 estgentot(gencount,daycount);
 estcsurplustot(buscount,demcount,daycount);
 estsocwelfare (daycount);


for (x=0; x<gencount; x++) nv1[x][3]=1;
for(x=0; x<buscount; x++) dv1[x][3]=1;
 for(x=0; x<buscount; x++)
   	{
     if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
          sBus[x].mgenstatus[y]=1;


         }

     if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        sBus[x].dem.dmstatus=1;

         }
 for (x=0; x<linecount; x++) sLine[x].status=0;
 cdemcount=0;
 mgencount=0;
 linecount1=0;
 oput<<"***********************************************************"<<"\n";
 oput<<"***********************************************************"<<"\n";




 };
  estdailytotals();
  sout<<"HOURLY TOTALS FOR DISTRIBUTIONAL MONOPOLY CASE"<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"NOTE: Generation, Load and Loss variables are in MWh."<<"\n";
   sout<<"      Social Welfare, Profit, Consumer Surplus variables are in"<<"\n";
   sout<<"      100000 TL. Price variables are in 100000 TL/MWh."<<"\n";
   sout<<"********************************************************"<<"\n";
   sout<<"TOTAL GENERATION     :"<<"\n";
   for (x=0; x<24; x++) sout<<gentot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOAD           :"<<"\n";
   for (x=0; x<24; x++) sout<<demt[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL LOSS           :"<<"\n";
   for (x=0; x<24; x++) sout<<lost[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL PROFITS        :"<<"\n";
   for (x=0; x<24; x++) sout<<proftot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS        :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL DISTRIBUTOR PROFITS        :"<<"\n";
   for (x=0; x<24; x++) sout<<dproftot[x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL SOCIAL WELFARE       :"<<"\n";
   for (x=0; x<24; x++) sout<<socwelfare[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot1[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"TOTAL CONSUMER SURPLUS IN NON-PRD       :"<<"\n";
   for (x=0; x<24; x++) sout<<csurplustot2[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE SELL PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgsprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE DISTRIBUTOR BUY PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgdbprice[x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"AVERAGE BUY PRICE        :"<<"\n";
   for (x=0; x<24; x++) sout<<avgbprice[choice][x]<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"---------------------------------------------------------"<<"\n";
   sout<<"*********************************************************"<<"\n";
   sout<<"							DAILY TOTALS                          "<<"\n";
   sout<<"GENERATION:			"<<dgentot[choice]<<"\n";
   sout<<"LOAD:	        		"<<ddemt[choice]<<"\n";
   sout<<"LOSS:					"<<dlost[choice]<<"\n";
   sout<<"PROFITS:				"<<dgproftot[choice]<<"\n";
   sout<<"CONSUMER SURPLUS:	"<<dcsurplustot[choice]<<"\n";
   sout<<"DISTR. PROFITS:		"<<ddproftot<<"\n";
   sout<<"SOCIAL WELFARE:		"<<dsocwelfare[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN PRD:		"<<dcsurplustot1[choice]<<"\n";
   sout<<"CONSUMER SURPLUS IN NON-PRD:	"<<dcsurplustot2[choice]<<"\n";


 oput.close();
 sout.close();
}




int main(){

   double kl,re;
   int x,l,rl,y,ch;
   double nv1[MAX][8],tempr[MAX];
   int nv11[MAX],dv11[MAX];
   double dv1[MAX][9];
   Gen gend[5];

   double nn1,nn2,nn3;


   ifstream inputfile("tessinput.txt");
   inputfile>>buscount;
   inputfile>>linecount;
   for (x=0; x<buscount; x++)
   	{
        sBus[x].bus_no=x;

        inputfile>>l;
        sBus[x].get_bus_type(l);
        if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
        				{
                     inputfile>>rl;
                     sBus[x].get_genno(rl);
                     }
        inputfile>>l;
        sBus[x].rdum=l;

        if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))
        	{

           sBus[x].dem.get_bdem(inputfile);
           sBus[x].dem.getdempar(inputfile);
           inputfile>>kl;
           sBus[x].dem.get_dmin(kl);
           inputfile>>kl;
           sBus[x].dem.get_dmax(kl);
           inputfile>>l;
           sBus[x].dem.get_cstatus(l);
           if (!(sBus[x].dem.cstatus==0))
           		{
                 	inputfile>>rl;
               	sBus[x].dem.get_dcontract(rl);
                  inputfile>>l;
                  sBus[x].dem.get_cbno(l);

                }
         }

        sBus[x].get_load();
        inputfile>>l;
        sBus[x].get_conno(l);
        sBus[x].get_condata(inputfile);
        sBus[x].initL2(sBus[x].con_no);
       if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
       	{
        for(y=0; y<sBus[x].genno; y++)
        	{

           inputfile>>nn1;
           inputfile>>nn2;
           inputfile>>nn3;
           sBus[x].get_genpar(nn1,nn2,nn3,gend,y);
           inputfile>>kl;
           sBus[x].get_max(kl,y);
           inputfile>>l;
           sBus[x].genb[y].get_cstatus(l);

           if (!(sBus[x].genb[y].cstatus==0))
           {
           	inputfile>>kl;

            sBus[x].genb[y].get_contract(kl);
            inputfile>>l;
            sBus[x].genb[y].get_cbno(l);
           }

        }
        }
      }


	for (x=0; x<linecount; x++)
   	{
        sLine[x].line_no=x;
        inputfile>>kl;
        sLine[x].getlinemax(kl);
        inputfile>>kl;
        inputfile>>re;
        sLine[x].get_suspectance(kl,re);
        sLine[x].initialstatus();
        sLine[x].get_statusf();
      }


   getbusno(buscount);
   gencount=0;
   for (x=0; x<buscount; x++)
   	{

        if ((sBus[x].bus_type==2)||(sBus[x].bus_type==3))
         for(y=0; y<sBus[x].genno; y++)
           {
        {
        nv1[gencount][0]=sBus[x].genb[y].A;
        nv1[gencount][1]=sBus[x].genb[y].B;
        nv1[gencount][2]=sBus[x].genb[y].C;
        nv1[gencount][3]=sBus[x].mgenstatus[y];
        nv1[gencount][4]=x;
        nv11[gencount]=x;
        nv1[gencount][6]=sBus[x].genb[y].cstatus;
        nv1[gencount][7]=sBus[x].genb[y].contract;
        gencount=gencount+1;
        }
        }
         }


	demcount=0;
      for (x=0; x<buscount; x++)
   	{

        if ((sBus[x].bus_type==1)||(sBus[x].bus_type==3))

        {
        dv1[demcount][0]=sBus[x].dem.A;
        dv1[demcount][3]=sBus[x].dem.dmstatus;
        dv1[demcount][4]=x;
        dv11[demcount]=x;
        dv1[demcount][6]=sBus[x].dem.cstatus;
        dv1[demcount][7]=sBus[x].dem.dcontract;
        dv1[demcount][8]=sBus[x].rdum;
        demcount=demcount+1;

        }
         }


  /* CHOICE SELECTION PART*/
	SLC:clrscr();
   cout<<"SELECT A ROUTINE TO RUN:"<<"\n";
	cout<<" 0. Benchmark Case: Administred Price Regulation Case"<<"\n";
	cout<<"		Output file for hourly values: aprhourly.txt"<<"\n";
	cout<<"		Output file for daily total values: aprdaily.txt"<<"\n";
   cout<<" 1. Free Consumer Case"<<"\n";
	cout<<"		Output file for hourly values: fcchourly.txt"<<"\n";
	cout<<"		Output file for daily total values: fccdaily.txt"<<"\n";
	cout<<" 2. Distributional Monopoly Case"<<"\n";
	cout<<"		Output file for hourly values: dmchourly.txt"<<"\n";
	cout<<"		Output file for daily total values: dmcdaily.txt"<<"\n";
   cout<<"Make Your Selection:"<<"\n";
	cin>>choice;


	if (choice==0)
   goto APR;
	else if (choice==1) goto FCC;
    else if (choice==2) goto DMC;
      else goto SLC;

	APR:
   {
    clrscr();
    apr(nv1,tempr);
    goto RTRY;
   }
	FCC:
   {
    clrscr();
    fcc(nv1,tempr,dv11,dv1);
   goto RTRY;
   }
    DMC:
   {
    clrscr();
    dmc(nv1,tempr,dv11,dv1);
    goto RTRY;
   }
  RTRY:cout<<"Do you want to continue ?"<<"\n";
  cout<<" 1. Yes "<<"\n";
  cout<<" 2. No "<<"\n";
  cin>>ch;
  if (ch==1) goto SLC;
  else if (ch==2) goto EXT;
  else goto RTRY;
  EXT: return 0;
}
