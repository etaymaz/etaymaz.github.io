## Version 0.0.1

With the change made in CBRT API in April 1924, the “key” value is required to be added to the HTTP Request Header in web service calls. The current version of the CBRT package (0.1.1) has been adapted to the required change. Since there is no change in function parameters, the users can use the code prepared for version 0.1.0 without any modification.

The functions 'getAllSeriesInfo', 'showGroupInfo' and 'getDataGroup' now includes the 'verbose' option. The default value is TRUE that prints some status and information messages to the console. 

